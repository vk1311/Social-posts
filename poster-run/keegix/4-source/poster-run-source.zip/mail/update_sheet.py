"""Add print columns + a Print list tab to keegix-dropoff-spots-valley.xlsx (22 Oct 2026)."""
import sys, json
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment

XLSX, PAGEMAP = sys.argv[1], sys.argv[2]
pm = json.load(open(PAGEMAP, encoding="utf-8"))
card_page = {n: p for p, n, *_ in pm["cards"]}
flyer_page = {n: p for p, n, *_ in pm["flyers"]}

F = "Arial"; navy = "15304A"
hdr_font = Font(name=F, bold=True, color="FFFFFF"); hdr_fill = PatternFill("solid", fgColor=navy)
thin = Side(style="thin", color="D3DCDA")
wb = load_workbook(XLSX)
ws = wb["Drop-off spots"]

rows = [r for r in range(5, ws.max_row + 1) if isinstance(ws.cell(r, 1).value, int)]
first, last = rows[0], rows[-1]
assert ws.cell(4, 8).value == "What to leave" and ws.cell(4, 17).value is None

heads = [("Gets key cards", 9), ("Key card PDF page", 9), ("Gets flyer 4", 9), ("Flyer 4 PDF page", 9)]
for k, (h, w) in enumerate(heads):
    c = ws.cell(4, 17 + k, h); c.font = hdr_font; c.fill = hdr_fill; c.alignment = Alignment(wrap_text=True, vertical="center")
    ws.column_dimensions[c.column_letter].width = w
ws.cell(4, 18).comment = Comment("Page in 10-CARD-option-A-keycards-37-spots.pdf. Rebuild the PDF if you change 'What to leave'.", "Keegix")
ws.cell(4, 20).comment = Comment("Page in 23-FLYER-option-4-airbnb-rules-21-spots.pdf. Rebuild the PDF if you change 'What to leave'.", "Keegix")

for r in rows:
    n = ws.cell(r, 1).value
    vals = [f'=IF(ISNUMBER(SEARCH("card",H{r})),"Yes","No")', card_page.get(n, "-"),
            f'=IF(OR(ISNUMBER(SEARCH("flyer",H{r})),ISNUMBER(SEARCH("tent",H{r})),ISNUMBER(SEARCH("board",H{r}))),"Yes","No")', flyer_page.get(n, "-")]
    for k, v in enumerate(vals):
        c = ws.cell(r, 17 + k, v); c.font = Font(name=F, size=9); c.alignment = Alignment(horizontal="center", vertical="top"); c.border = Border(bottom=thin)
ws.auto_filter.ref = f"A4:T{last}"

# ---- Print list tab ----
if "Print list" in wb.sheetnames:
    del wb["Print list"]
pl = wb.create_sheet("Print list", 1)
B = Font(name=F, bold=True, size=10); N = Font(name=F, size=10); H = Font(name=F, bold=True, size=13, color=navy)
pl["A1"] = "What to print (colour, office printer, 100% / Actual size)"; pl["A1"].font = H
ds = "'Drop-off spots'"; ml = "'Mail list (30)'"
table = [
    ("Cardstock (Pen+Gear 65 lb white)", None, None),
    ("Spot key cards: 10-CARD-option-A-keycards-37-spots.pdf (9 cards per sheet)", f'=COUNTIF({ds}!Q{first}:Q{last},"Yes")', "sheets"),
    ("Mail key cards: 02-mail-keycards-30-FRONT.pdf (9 per sheet, last sheet has 3)", f"=ROUNDUP(COUNTA({ml}!A2:A31)/9,0)", "sheets"),
    ("Total cardstock", "=B4+B5", "sheets"),
    ("Key card backs: 03-keycards-BACK.pdf, print on the reverse of every key card sheet above (no extra sheets)", "=B6", "copies"),
    ("Copy paper", None, None),
    ("Flyer 4, Airbnb house rules: 23-FLYER-option-4-airbnb-rules-21-spots.pdf (until Nov 20)", f'=COUNTIF({ds}!S{first}:S{last},"Yes")', "sheets"),
    ("Mail letters: 01-mail-letters-30.pdf", f"=COUNTA({ml}!A2:A31)", "sheets"),
    ("Total copy paper", "=B9+B10", "sheets"),
    ("After Nov 20: flyer 3 tear-off, 22-FLYER-option-3-tearoff-per-spot.pdf, print only the flyer spots' pages (page = spot number)", "=B9", "sheets"),
]
for k, (a, b, c) in enumerate(table, 3):
    pl.cell(k, 1, a).font = B if (b is None or a.startswith("Total")) else N
    if b is not None:
        pl.cell(k, 2, b).font = B if a.startswith("Total") else N
        pl.cell(k, 3, c).font = N
pl.column_dimensions["A"].width = 100; pl.column_dimensions["B"].width = 8; pl.column_dimensions["C"].width = 8

pl.cell(14, 1, "Which page is which spot: see the Page to spot tab.").font = Font(name=F, italic=True, size=9, color="4E5C66")

if "Page to spot" in wb.sheetnames:
    del wb["Page to spot"]
pts = wb.create_sheet("Page to spot", 2)
def page_table(top, col, title, rows_, code_hdr):
    pts.cell(top, col, title).font = B
    for k, h in enumerate(["PDF page", "Spot #", "Place", "Town", code_hdr]):
        c = pts.cell(top + 1, col + k, h); c.font = hdr_font; c.fill = hdr_fill
    for i, (p, n, name, town, code) in enumerate(rows_):
        for k, v in enumerate([p, n, name, town, code]):
            pts.cell(top + 2 + i, col + k, v).font = Font(name=F, size=9)
page_table(1, 1, "Key cards: 10-CARD-option-A-keycards-37-spots.pdf", pm["cards"], "Card code")
page_table(1, 7, "Flyer 4: 23-FLYER-option-4-airbnb-rules-21-spots.pdf", pm["flyers"], "Flyer code")
for col, w in zip("ABCDEFGHIJK", [9, 7, 40, 16, 10, 3, 9, 7, 40, 16, 10]):
    pts.column_dimensions[col].width = w
pts.freeze_panes = "A3"

# note on the How-the-codes-work tab
hw = wb["How the codes work"]
r = hw.max_row + 2
hw.cell(r, 1, "Print run (22 Oct 2026)").font = Font(name=F, bold=True, size=12, color=navy)
hw.cell(r + 1, 1, "Using card option A (key cards) and flyer option 4 (Airbnb house rules) until Nov 20, then flyer option 3 (tear-off). "
                  "Gets key cards / Gets flyer 4 come from 'What to leave'. See the Print list tab for pages and sheet counts.").font = Font(name=F, size=10)
wb.save(XLSX)
print("rows", first, last)
