"""Trimmed per-spot PDFs for the Keegix poster run (22 Oct 2026).
Only the spots that need them, chosen from 'What to leave' in keegix-dropoff-spots-valley.xlsx:
  key cards (option A) -> spots whose 'What to leave' mentions cards
  flyer 4 (Airbnb house rules) -> spots whose 'What to leave' mentions a flyer, tent or board
Codes stay exactly as before: cards C##, flyers L## (## = spot number).
Usage: python3 build_trimmed.py <spreadsheet.xlsx> <out_dir>"""
import os, sys, json, html
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
XLSX, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)

# Reuse the v3 design code (everything before the job list) so pages look and scan the same.
src = open(os.path.join(HERE, "build_v3.py"), encoding="utf-8").read()
exec(src.split("\nS = spots")[0])  # defines tag_svg, keycard_sheet, news, doc, CARD_CSS, NEWS_CSS, spots, esc ...
OUT = sys.argv[2]  # the v3 code sets its own OUT; use ours

ws = load_workbook(XLSX)["Drop-off spots"]
sheet = []
for r in ws.iter_rows(min_row=5, values_only=True):
    if not isinstance(r[0], int):
        continue
    leave = (r[7] or "").lower()
    sheet.append(dict(n=r[0], town=r[1], name=r[2], leave=r[7], card=r[9].lower(), flyer=r[10].lower(),
                      gets_cards="card" in leave, gets_flyer=any(w in leave for w in ("flyer", "tent", "board"))))
by_n = {s["n"]: s for s in spots}
for s in sheet:  # the design data and the spreadsheet must agree
    d = by_n[s["n"]]
    assert (d["name"], d["cards"], d["flyer"]) == (s["name"], s["card"], s["flyer"]), (s, d)

cards = [s for s in sheet if s["gets_cards"]]
flyers = [s for s in sheet if s["gets_flyer"]]

LABEL_CSS = """
.foot{bottom:.26in !important;font-size:7.5pt !important;color:#5d6b76 !important}
.spot{position:absolute;left:.8in;right:.8in;bottom:.26in;font-size:7.5pt;color:#5d6b76;text-align:center}
"""

def card_page(i, s):
    note = (f"Page {i} of {len(cards)} · Spot {s['n']}: {esc(s['name'])} ({esc(s['town'])}) · "
            f"9 key cards, code {s['card'].upper()} · cardstock, cut along the yellow shape")
    return keycard_sheet([s["card"]] * 9, note)

def flyer_page(i, s):
    page = news(s["flyer"])
    label = (f'<div class="spot">Page {i} of {len(flyers)} · Spot {s["n"]}: {esc(s["name"])} ({esc(s["town"])}) · '
             f'flyer code {s["flyer"].upper()}</div>')
    assert page.endswith("</div>")
    return page[:-len("</div>")] + label + "</div>"

jobs = {
    "10-CARD-option-A-keycards-37-spots.pdf": doc(CARD_CSS + LABEL_CSS, "".join(card_page(i, s) for i, s in enumerate(cards, 1))),
    "23-FLYER-option-4-airbnb-rules-21-spots.pdf": doc(NEWS_CSS + LABEL_CSS, "".join(flyer_page(i, s) for i, s in enumerate(flyers, 1))),
}
assert len(cards) == 37 and len(flyers) == 21, (len(cards), len(flyers))

from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    for name, h in jobs.items():
        f = os.path.join(OUT, "_trim.html"); open(f, "w", encoding="utf-8").write(h)
        pg.goto(f"file://{f}"); pg.wait_for_timeout(600)
        pg.pdf(path=os.path.join(OUT, name), prefer_css_page_size=True, print_background=True)
        os.remove(f)
    b.close()

json.dump({"cards": [[i, s["n"], s["name"], s["town"], s["card"].upper()] for i, s in enumerate(cards, 1)],
           "flyers": [[i, s["n"], s["name"], s["town"], s["flyer"].upper()] for i, s in enumerate(flyers, 1)]},
          open(os.path.join(OUT, "page-map.json"), "w"), ensure_ascii=False, indent=1)
print(len(cards), "card pages,", len(flyers), "flyer pages")
