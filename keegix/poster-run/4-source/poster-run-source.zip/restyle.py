"""Rebuild the 8 keegix.com QR sign styles with our own link.
Each style SVG = shape + 3 rounded finder eyes + dot modules (r=.45) on a 25x25 grid,
plus decorative dots (r=.36) outside the code. We keep everything except the r=.45
data dots inside the code area, and draw our own matrix there."""
import re, sys, qrcode

SRC = "/tmp/kt/styles"
STYLES = ["tag-yellow", "tag-navy", "tag-dots", "house", "door", "bubble", "circle", "square"]

def matrix(url):
    q = qrcode.QRCode(version=2, error_correction=qrcode.constants.ERROR_CORRECT_L, border=0)
    q.add_data(url)
    q.make(fit=False)
    m = q.get_matrix()
    assert len(m) == 25, len(m)
    return m

def in_finder(r, c):
    return (r < 8 and c < 8) or (r < 8 and c > 16) or (r > 16 and c < 8)

def restyle(style, url):
    s = open(f"{SRC}/sign-{style}.svg").read()
    # origin = outer edge of the first (top-left) eye: path "M{x+2.2} {y}H..."
    eyes = [(float(a), float(b)) for a, b, h in re.findall(r'<path d="M([\d.]+) ([\d.]+)H([\d.]+)A2\.2 2\.2', s)
            if abs(float(h) - float(a) - 2.6) < .01]   # outer eye ring is 2.6 wide between corners
    x0, y0 = eyes[0][0] - 2.2, eyes[0][1]
    m = matrix(url)

    def keep(match):
        cx, cy, r = float(match.group(1)), float(match.group(2)), match.group(3)
        inside = x0 - .01 <= cx <= x0 + 25.01 and y0 - .01 <= cy <= y0 + 25.01
        return "" if (r == "0.45" and inside) else match.group(0)

    s = re.sub(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="([\d.]+)"/>', keep, s)
    # dot colour = colour of the first <g> (the module group)
    dots = []
    for r in range(25):
        for c in range(25):
            if m[r][c] and not in_finder(r, c):
                dots.append(f'<circle cx="{x0 + c + .5:g}" cy="{y0 + r + .5:g}" r="0.45"/>')
    s = re.sub(r'(<g fill="#[0-9a-f]+">)', lambda mm: mm.group(1) + "".join(dots), s, count=1)
    return s

if __name__ == "__main__":
    url, prefix = sys.argv[1], sys.argv[2]
    for st in STYLES:
        open(f"{prefix}-{st}.svg", "w").write(restyle(st, url))
    print("done", url)
