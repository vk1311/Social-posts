import json, re, csv
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

raw = json.load(open("spots_raw1.json")) + json.load(open("spots_raw2.json"))
by = {p["name"]: p for p in raw}

# (name, category, what to leave, why) — chosen spots; town order runs west to east along Hwy 1/101
PICK = [
 ("Annapolis Royal Visitor Information Centre", "Visitor centre", "Key cards in the rack + flyer", "Tourists and new owners ask here; staff know every B&B"),
 ("Lazy Daisy Café", "Café", "Key cards at the till + flyer/tent", "Main street café in a heavy B&B town"),
 ("ARCH & PO", "Café / bakery", "Key cards at the till", "Busy bakery on St George St"),
 ("Fort Anne Cafe", "Café", "Key cards + flyer if there's a board", "Diner next to Fort Anne, tourist traffic"),
 ("Annapolis Home Hardware Building Centre", "Hardware", "Key cards at the till (ask)", "Owners fixing up rentals shop here"),
 ("Rockin' Rogi Diner", "Café / diner", "Key cards + flyer if there's a board", "Middleton main street"),
 ("Green Elephant Café", "Café", "Key cards + flyer/tent", "Very busy (870+ reviews), Kingston"),
 ("North Mountain Fine Coffees", "Café", "Key cards + flyer/tent", "Berwick's main coffee spot"),
 ("Wheaton's Cider Press Cafe", "Café", "Key cards at the till", "Berwick"),
 ("Berwick Home Hardware Building Centre", "Hardware", "Key cards at the till (ask)", "Owners fixing up rentals"),
 ("Berwick and District Library", "Library", "Flyer on the community board", "Free community board"),
 ("Sourdough Country Bakery and Windmill Cafe", "Café / bakery", "Key cards at the till", "Hwy 1 stop in Cambridge"),
 ("Wheelhouse Coffee Co.", "Café", "Key cards + flyer/tent", "Kentville, local crowd"),
 ("T.A.N. Coffee - Kentville", "Café", "Key cards + flyer/tent", "Kentville Main St"),
 ("Half Acre Cafe", "Café", "Key cards at the till", "Kentville Main St"),
 ("Kentville Library", "Library", "Flyer on the community board", "Free community board"),
 ("Kentville Farmers Market", "Farmers market", "Key cards at the info table (ask)", "Locals who own property"),
 ("Rockwell Home Hardware", "Hardware", "Key cards at the till (ask)", "Kentville Main St"),
 ("Maytag Coin Laundry", "Laundromat", "Flyer on the board", "Small hosts wash linens here"),
 ("Fraser’s Pro Home Centre", "Hardware", "Key cards at the pro desk (ask)", "Contractors who work on rentals"),
 ("Kent Building Supplies", "Hardware", "Key cards at the till (ask)", "Biggest building store in the Valley"),
 ("Nothin' Fancy Furniture Warehouse", "Furniture", "Key cards at the till (ask)", "People furnishing a new rental"),
 ("Hampton House Furniture", "Furniture", "Key cards at the till (ask)", "People furnishing a new rental"),
 ("The Village Coffeehouse", "Café", "Key cards + flyer/tent", "Canning, near Blomidon rentals"),
 ("Art Can Kitchen and Studios", "Café / community", "Flyer + key cards", "Canning community hub"),
 ("Baked Inn Homemade", "Bakery", "Key cards at the till", "Centreville, on the way to Hall's Harbour"),
 ("Elderkin's Farm Market, Bakery, & U-Pick", "Farm market", "Key cards at the till", "Hwy 1 farm market"),
 ("Hennigar's Farm Market", "Farm market", "Key cards at the till + flyer", "Very busy (1,600+ reviews)"),
 ("Charts Café", "Café", "Key cards + flyer/tent", "Wolfville, next to the farmers market"),
 ("Just Us! Wolfville Café", "Café", "Key cards + flyer/tent", "Wolfville Main St, busy"),
 ("T.A.N. Coffee - Wolfville", "Café", "Key cards + flyer/tent", "Wolfville Main St, busy"),
 ("Juniper Luncheonette", "Café", "Key cards at the till", "Wolfville Main St"),
 ("Wolfville Farmers' Market", "Farmers market", "Key cards at the info table (ask)", "Biggest market in the Valley, Saturdays"),
 ("Wolfville Memorial Library", "Library", "Flyer on the community board", "Free community board"),
 ("Rafuse Home Hardware Building Centre", "Hardware", "Key cards at the till (ask)", "Wolfville"),
 ("MacKay Real Estate", "Real estate", "Hand key cards to an agent", "Agents sell to people buying rentals"),
 ("Sherri & Carrie - Annapolis Valley Real Estate Team", "Real estate", "Hand key cards to an agent", "Agents sell to people buying rentals"),
 ("Studio 14 Gifts & Gallery", "Gift shop", "Key cards at the till", "Tourist shop near Wolfville"),
 ("Just Us! Grand Pré Café & Roastery", "Café", "Key cards + flyer/tent", "Grand Pré wine-country traffic"),
 ("The Border Diner & Grill", "Diner", "Key cards + flyer if there's a board", "Hantsport"),
 ("GERRISH & GRAY CAFE", "Café", "Key cards + flyer/tent", "Windsor"),
]

def town(addr):
    parts = [x.strip() for x in addr.split(",")]
    return parts[-3] if len(parts) >= 3 else ""

def short_hours(h):
    if not h: return "Not listed: check before going"
    h = h.replace(" ", " ").replace(" ", "").replace("–", "–")
    for long, s in [("Monday","Mon"),("Tuesday","Tue"),("Wednesday","Wed"),("Thursday","Thu"),("Friday","Fri"),("Saturday","Sat"),("Sunday","Sun")]:
        h = h.replace(long + ":", s)
    h = h.replace(":00", "").replace(" AM", "am").replace(" PM", "pm")
    return h

rows = []
for i, (name, cat, leave, why) in enumerate(PICK, 1):
    p = by[name]
    addr = p["address"].replace(", Canada", "")
    rows.append(dict(n=i, town=town(p["address"]), name=name, cat=cat, addr=addr, phone=p["phone"].replace("+1 ", ""),
                     hours=short_hours(p["hours"]), leave=leave, why=why, cards=f"c{i:02d}", flyer=f"l{i:02d}",
                     maps=f"https://www.google.com/maps/search/?api=1&query={name.replace(' ', '+').replace('&','and')}&query_place_id={p['place_id']}"))
json.dump(rows, open("spots_final.json", "w"), ensure_ascii=False, indent=1)

wb = Workbook()
F = "Arial"
navy = "15304A"; yellow = "F4C430"; sea = "E3ECE9"
hdr_font = Font(name=F, bold=True, color="FFFFFF"); hdr_fill = PatternFill("solid", fgColor=navy)
fill_in = PatternFill("solid", fgColor="FFF6D6")
thin = Side(style="thin", color="D3DCDA")

ws = wb.active; ws.title = "Drop-off spots"
ws["A1"] = "Keegix drop-off spots: Annapolis Valley (listed west to east)"; ws["A1"].font = Font(name=F, bold=True, size=14, color=navy)
ws["A2"] = "Yellow columns are yours to fill in. Each spot has its own codes: leave key cards printed with its card code and the flyer/tent printed with its flyer code."
ws["A2"].font = Font(name=F, italic=True, size=9, color="4E5C66")
heads = ["#","Town","Place","Type","Address","Phone","Hours (from Google, check before going)","What to leave","Why here","Card code","Flyer code","Route order","Visited on","Left what (cards/flyer/tent)","Notes","Map"]
widths = [4,15,34,15,40,14,46,30,36,9,9,10,12,18,28,10]
for c, (h, w) in enumerate(zip(heads, widths), 1):
    cell = ws.cell(row=4, column=c, value=h); cell.font = hdr_font; cell.fill = hdr_fill
    cell.alignment = Alignment(wrap_text=True, vertical="center"); ws.column_dimensions[get_column_letter(c)].width = w
for c in (12, 13, 14, 15):
    ws.cell(row=4, column=c).fill = PatternFill("solid", fgColor="B8860B")
r0 = 5
for k, r in enumerate(rows):
    vals = [r["n"], r["town"], r["name"], r["cat"], r["addr"], r["phone"], r["hours"], r["leave"], r["why"], r["cards"].upper(), r["flyer"].upper(), None, None, None, None, "Open map"]
    for c, v in enumerate(vals, 1):
        cell = ws.cell(row=r0 + k, column=c, value=v); cell.font = Font(name=F, size=9)
        cell.alignment = Alignment(wrap_text=True, vertical="top"); cell.border = Border(bottom=thin)
        if c in (12, 13, 14, 15): cell.fill = fill_in
    m = ws.cell(row=r0 + k, column=16); m.hyperlink = r["maps"]; m.font = Font(name=F, size=9, color="0563C1", underline="single")
# example row guidance in the fill-in columns of the first row
ws.cell(row=r0, column=12).comment = None
ws.freeze_panes = "D5"
ws.auto_filter.ref = f"A4:P{r0 + len(rows) - 1}"
last = r0 + len(rows) - 1
ws.cell(row=last + 2, column=2, value="Spots visited").font = Font(name=F, bold=True, size=9)
ws.cell(row=last + 2, column=3, value=f"=COUNTA(M{r0}:M{last})").font = Font(name=F, bold=True, size=9)
ws.cell(row=last + 3, column=2, value="Spots listed").font = Font(name=F, size=9)
ws.cell(row=last + 3, column=3, value=f"=COUNTA(C{r0}:C{last})").font = Font(name=F, size=9)

# Mail list
ws2 = wb.create_sheet("Mail list (30)")
mail = list(csv.DictReader(open("mail-30.csv", encoding="utf-8")))
h2 = ["Code","Place","Type","Region","Address","City","Province","Postcode","Phone","Mailed on","Notes"]
w2 = [7,36,11,12,26,18,8,10,14,12,28]
for c, (h, w) in enumerate(zip(h2, w2), 1):
    cell = ws2.cell(row=1, column=c, value=h); cell.font = hdr_font; cell.fill = hdr_fill; ws2.column_dimensions[get_column_letter(c)].width = w
for c in (10, 11): ws2.cell(row=1, column=c).fill = PatternFill("solid", fgColor="B8860B")
for k, m in enumerate(mail, 2):
    vals = [m["code"].upper(), m["name"], m["type"], m["region"], m["address1"], m["city"], m["province"], m["postcode"], m["phone"], None, None]
    for c, v in enumerate(vals, 1):
        cell = ws2.cell(row=k, column=c, value=v); cell.font = Font(name=F, size=9)
        if c in (10, 11): cell.fill = fill_in
ws2.freeze_panes = "C2"

# How it works
ws3 = wb.create_sheet("How the codes work")
lines = [
 ("How the codes work", True),
 ("Every printed QR code opens keegix.com/demo (a sample guest page) with its own code, e.g. keegix.com/demo?src=c07.", False),
 ("Card code (C01–C41): the key cards you leave at that spot. Flyer code (L01–L41): the flyer, tent or poster you leave there.", False),
 ("M01–M30: the mailed letters, one per place (see the Mail list tab).", False),
 ("Scans for each code show up in the Keegix print tracker (Google Sheet) once they are checked.", False),
 ("", False),
 ("Fill in (yellow columns)", True),
 ("Route order: number the stops after you combine lists. Visited on: the date. Left what: cards, flyer or tent. Notes: who you spoke to, if they said no, etc.", False),
 ("Example: Route order 3 · Visited on 2026-10-25 · Left what: 9 cards + tent · Notes: owner Sam said OK, will put tent by the till.", False),
 ("", False),
 ("Sources", True),
 ("Places, addresses, phones and hours: Google Maps listings pulled 21 Oct 2026. Hours change by season, so check before you drive.", False),
]
for k, (t, b) in enumerate(lines, 1):
    c = ws3.cell(row=k, column=1, value=t); c.font = Font(name=F, bold=b, size=12 if b else 10, color=navy if b else "000000")
ws3.column_dimensions["A"].width = 130
wb.save("/tmp/kt/out3/keegix-dropoff-spots-valley.xlsx")
print(len(rows), "spots")
