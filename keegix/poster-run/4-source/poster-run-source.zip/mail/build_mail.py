import csv, os, html
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/pw-browsers"
from playwright.sync_api import sync_playwright

D = "/tmp/kt"
OUT = "/tmp/kt/out"
rows = [r for r in csv.DictReader(open(f"{D}/mail/keegix-mail-test-50.csv", encoding="utf-8"))]
A = [r for r in rows if r["group"].startswith("A")]

FONTS = f"""
@font-face{{font-family:'Archivo';font-weight:400 800;font-stretch:62% 125%;src:url(file://{D}/fonts/Archivo-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:normal;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:italic;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-italic.woff2) format('woff2')}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Archivo,sans-serif;color:#15304A;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
"""

def note(r):
    name = html.escape(r["name"])
    return f"""<div class="note">
  <img class="lock" src="file://{D}/logo-lockup-navy.png">
  <p class="hi">Hi everyone at {name},</p>
  <p>I'm Vatsal, from Kentville. I made Keegix: a welcome book your guests open on their phone, with check-in steps, wifi, parking, house rules and the checkout list, behind one QR sign by the door. No app for guests to download.</p>
  <p><b>The yellow key tag in this envelope opens a sample cottage.</b> Scan it with your phone camera the way a guest would.</p>
  <p>I'm looking for a few Nova Scotia places to be founding hosts: <b>Pro free until the end of 2027</b>, no card and no call. If you'd rather not set it up yourself, send me what you already give guests and I'll build it for you.</p>
  <p class="sig">Thanks for reading,<br><span class="name">Vatsal Thakkar</span><br>Keegix · contact@keegix.com · keegix.com/founding</p>
</div>"""

NOTE_CSS = """
@page{size:8.5in 11in;margin:0}
.page{width:8.5in;height:11in;position:relative;page-break-after:always}
.half{position:absolute;left:0;width:8.5in;height:5.5in;display:flex;align-items:center;justify-content:center}
.half.top{top:0}.half.bot{top:5.5in}
.cut{position:absolute;top:5.5in;left:.3in;right:.3in;border-top:1px dashed #c3ccd2}
.note{width:6.6in;font-size:11pt;line-height:1.45}
.note .lock{width:1.2in;margin-bottom:.18in}
.note p{margin-bottom:.12in}
.note .hi{font-family:Newsreader,serif;font-size:15pt;font-weight:500;margin-bottom:.1in}
.note b{font-weight:700}
.note .sig{margin-top:.18in;font-size:10pt;color:#4E5C66}
.note .sig .name{font-family:Newsreader,serif;font-style:italic;font-size:14pt;color:#15304A}
"""

def notes_html():
    pages = []
    for i in range(0, len(A), 2):
        top = note(A[i]); bot = note(A[i + 1]) if i + 1 < len(A) else ""
        pages.append(f'<div class="page"><div class="half top">{top}</div><div class="cut"></div><div class="half bot">{bot}</div></div>')
    return f"<html><head><style>{FONTS}{NOTE_CSS}</style></head><body>{''.join(pages)}</body></html>"

# Avery 5160 / 8160: 30 labels, 3 x 10, 2.625in x 1in, top margin .5in, left .1875in, column pitch 2.75in
LABEL_CSS = """
@page{size:8.5in 11in;margin:0}
.sheet{width:8.5in;height:11in;position:relative;page-break-after:always}
.lab{position:absolute;width:2.625in;height:1in;padding:.1in .16in;font-size:9pt;line-height:1.25;display:flex;flex-direction:column;justify-content:center}
.lab b{font-weight:700}
.foot{position:absolute;bottom:.15in;width:100%;text-align:center;font-size:7pt;color:#9aa7b0}
"""

def labels_html():
    cells = []
    for i, r in enumerate(A):
        col, row = i % 3, i // 3
        x = 0.1875 + col * 2.75; y = 0.5 + row * 1.0
        cells.append(f'<div class="lab" style="left:{x}in;top:{y}in"><b>{html.escape(r["name"])}</b>{html.escape(r["address1"])}<br>{html.escape(r["city"])} {r["province"]}  {r["postcode"]}</div>')
    return f"<html><head><style>{FONTS}{LABEL_CSS}</style></head><body><div class='sheet'>{''.join(cells)}<div class='foot'>Avery 5160 / 8160 labels (30 per sheet) · print at 100% (Actual size)</div></div></body></html>"

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    for name, h in [("keegix-mail-notes-25.pdf", notes_html()), ("keegix-mail-labels-avery5160.pdf", labels_html())]:
        f = f"{D}/mail/_tmp.html"; open(f, "w").write(h)
        pg.goto(f"file://{f}"); pg.wait_for_timeout(400)
        pg.pdf(path=f"{OUT}/{name}", prefer_css_page_size=True, print_background=True)
    b.close()
print("ok", len(A))
