"""Mail letters (window envelope, tri-fold) + numbered key cards + public-place cards and counter letters.
Every piece has its own code: keegix.com/demo?src=<code> (m01-m30 mail, c01-c10 cards, l01-l10 counter letters)."""
import csv, os, html, sys
sys.path.insert(0, "/tmp/kt")
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/pw-browsers"
import restyle
from playwright.sync_api import sync_playwright

D = "/tmp/kt"; OUT = "/tmp/kt/out2"; os.makedirs(OUT, exist_ok=True)
SPOTS = int(os.environ.get("SPOTS", "10"))
mail = list(csv.DictReader(open(f"{D}/mail/mail-30.csv", encoding="utf-8")))
esc = html.escape

def tag_svg(code, label=True):
    s = restyle.restyle("tag-yellow", f"https://keegix.com/demo?src={code}")
    extra = ""
    if label:
        extra = (f'<text x="19" y="46.6" text-anchor="middle" font-family="Archivo" font-weight="800" font-size="3.1" '
                 f'style="font-stretch:118%" fill="#15304a">keegix.com</text>'
                 f'<text x="19" y="51.2" text-anchor="middle" font-family="Archivo" font-weight="700" font-size="2.1" '
                 f'letter-spacing=".25" fill="#15304a">{code.upper()}</text>')
    s = s.replace("</svg>", extra + "</svg>")
    return s.replace("<svg ", '<svg style="width:100%;height:100%;display:block" ', 1)

FONTS = f"""
@font-face{{font-family:'Archivo';font-weight:400 800;font-stretch:62% 125%;src:url(file://{D}/fonts/Archivo-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:normal;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:italic;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-italic.woff2) format('woff2')}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Archivo,sans-serif;color:#15304A;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
@page{{size:8.5in 11in;margin:0}}
.page{{width:8.5in;height:11in;position:relative;overflow:hidden;page-break-after:always}}
.kick{{font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-stretch:125%}}
.serif{{font-family:Newsreader,serif;font-weight:500;letter-spacing:-.02em}}
"""

# ---------- mail letter: #10 window envelope, letter (Z) fold ----------
# Standard #10 window: 4.5 x 1.125in, 7/8in from left, 1/2in from bottom -> 2.5in-3.625in from the envelope top.
LETTER_CSS = """
.logo{position:absolute;left:1in;top:.6in;width:1.15in}
.code{position:absolute;right:.6in;top:.62in;font-size:7.5pt;color:#9aa7b0;letter-spacing:.06em}
.addr{position:absolute;left:1.05in;top:2.55in;width:3.9in;font-size:10.5pt;line-height:1.28}
.addr b{font-weight:700}
.fold{position:absolute;width:.25in;border-top:1px solid #d3dcda}
.body{position:absolute;left:1in;top:4.0in;width:4.55in;font-size:10.6pt;line-height:1.45}
.body p{margin-bottom:.11in}
.body .hi{font-family:Newsreader,serif;font-weight:500;font-size:14.5pt;margin-bottom:.09in}
.body b{font-weight:700}
.sig{font-size:9.6pt;color:#4E5C66;margin-top:.14in}
.sig .nm{font-family:Newsreader,serif;font-style:italic;font-size:13.5pt;color:#15304A}
.slot{position:absolute;left:5.9in;top:7.52in;width:2.2in;height:3.37in;border:1.2px dashed #c3ccd2;border-radius:.12in;
      display:flex;align-items:center;justify-content:center;text-align:center;font-size:7.5pt;color:#9aa7b0;padding:.2in}
"""

def letter(r):
    n = esc(r["name"])
    return f"""<div class="page">
  <img class="logo" src="file://{D}/logo-lockup-navy.png">
  <div class="code">{r['code'].upper()}</div>
  <div class="addr"><b>{n}</b><br>{esc(r['address1'])}<br>{esc(r['city'])} {r['province']}&nbsp;&nbsp;{r['postcode']}</div>
  <div class="fold" style="left:.25in;top:3.667in"></div><div class="fold" style="right:.25in;top:3.667in"></div>
  <div class="fold" style="left:.25in;top:7.333in"></div><div class="fold" style="right:.25in;top:7.333in"></div>
  <div class="body">
    <p class="hi">Hi everyone at {n},</p>
    <p>I'm Vatsal, from Kentville. I made Keegix: a welcome book your guests open on their phone, with check-in steps, wifi, parking, house rules and the checkout list, behind one QR sign by the door. No app for guests to download.</p>
    <p><b>The yellow key card with this letter opens a sample cottage.</b> Point your phone camera at it the way a guest would.</p>
    <p>I'm looking for a few Nova Scotia places to be founding hosts: <b>Pro free until the end of 2027</b>, no card and no call. If you'd rather not set it up yourself, send me what you already give guests and I'll build it for you.</p>
    <p class="sig">Thanks for reading,<br><span class="nm">Vatsal Thakkar</span><br>Keegix · contact@keegix.com · keegix.com/founding</p>
  </div>
  <div class="slot">Tape key card {r['code'].upper()} here</div>
</div>"""

# ---------- key cards: 2.2 x 3.37in, 3 x 3 per letter sheet ----------
CARD_W, CARD_H = 2.2, 3.37
GX = (8.5 - 3 * CARD_W) / 2; GY = (11 - 3 * CARD_H) / 2
CARD_CSS = f"""
.card{{position:absolute;width:{CARD_W}in;height:{CARD_H}in}}
.foot{{position:absolute;bottom:.12in;width:100%;text-align:center;font-size:7pt;color:#9aa7b0}}
.back{{display:flex;flex-direction:column;align-items:center;text-align:center;padding:.62in .22in 0}}
.back img{{width:1.05in;margin-bottom:.12in}}
.back .l1{{font-family:Newsreader,serif;font-weight:500;font-size:10.5pt;line-height:1.15;margin-bottom:.1in}}
.back .l2{{font-size:7.2pt;font-weight:700;line-height:1.3;margin-bottom:.06in}}
.back .l3{{font-size:6.6pt;color:#4E5C66;line-height:1.3}}
"""

def card_pos(i):
    return GX + (i % 3) * CARD_W, GY + (i // 3) * CARD_H

def card_sheet(codes, note):
    cells = "".join(f'<div class="card" style="left:{card_pos(i)[0]}in;top:{card_pos(i)[1]}in">{tag_svg(c)}</div>' for i, c in enumerate(codes))
    return f'<div class="page">{cells}<div class="foot">{note}</div></div>'

def back_sheet(note):
    b = (f'<div class="back"><img src="file://{D}/logo-lockup-navy.png"><div class="l1">A welcome book your guests open on their phone.</div>'
         f'<div class="l2">Founding hosts: Pro free until the end of 2027. No card.</div><div class="l3">contact@keegix.com</div></div>')
    cells = "".join(f'<div class="card" style="left:{card_pos(i)[0]}in;top:{card_pos(i)[1]}in">{b}</div>' for i in range(9))
    return f'<div class="page">{cells}<div class="foot">{note}</div></div>'

# ---------- counter letter for public spots ----------
COUNTER_CSS = """
.c-k{position:absolute;left:.85in;top:.9in;font-size:8.5pt;color:#4E5C66}
.c-h{position:absolute;left:.85in;top:1.2in;width:6.8in;font-size:44pt;line-height:1.02}
.c-h em{font-style:italic;color:#b8860b}
.c-b{position:absolute;left:.85in;top:3.35in;width:3.7in;font-size:11.5pt;line-height:1.5}
.c-b p{margin-bottom:.14in}
.c-b b{font-weight:700}
.c-tag{position:absolute;left:5.0in;top:3.2in;width:2.65in;height:4.05in}
.c-scan{position:absolute;left:5.0in;top:7.4in;width:2.65in;text-align:center;font-size:9pt;font-weight:700}
.c-foot{position:absolute;left:.85in;bottom:.8in;width:6.8in;border-top:1px solid #d3dcda;padding-top:.12in;font-size:9pt;color:#4E5C66;display:flex;justify-content:space-between}
.c-logo{position:absolute;left:.85in;bottom:1.25in;width:1.3in}
"""

def counter(code):
    return f"""<div class="page">
  <div class="kick c-k">For anyone who rents out a cottage, room or cabin</div>
  <div class="serif c-h">The 11:47 PM wifi text? <em>Let the house answer it.</em></div>
  <div class="c-b">
    <p>Keegix is a welcome book your guests open on their phone: check-in steps, wifi, parking, house rules and the checkout list, behind one QR sign by the door.</p>
    <p><b>Founding hosts in Nova Scotia get Pro free until the end of 2027.</b> No card, no call. I'm Vatsal, I live in Kentville, and I'll build it from your notes if you'd rather not.</p>
    <p>Take a yellow key card if there are some here.</p>
  </div>
  <div class="c-tag">{tag_svg(code)}</div>
  <div class="c-scan">Scan it the way a guest would:<br>it opens a sample cottage.</div>
  <img class="c-logo" src="file://{D}/logo-lockup-navy.png">
  <div class="c-foot"><span>keegix.com/founding · contact@keegix.com</span><span>{code.upper()}</span></div>
</div>"""

def doc(css, body):
    return f"<html><head><meta charset=\"utf-8\"><style>{FONTS}{css}</style></head><body>{body}</body></html>"

jobs = {}
jobs["1-mail-letters-30.pdf"] = doc(LETTER_CSS, "".join(letter(r) for r in mail))
codes = [r["code"] for r in mail]
jobs["2-mail-keycards-30-FRONT.pdf"] = doc(CARD_CSS, "".join(
    card_sheet(codes[i:i + 9], f"Mail key cards {codes[i].upper()}–{codes[min(i+8,len(codes)-1)].upper()} · cardstock · print at 100% (Actual size) · cut along the yellow shape")
    for i in range(0, len(codes), 9)))
jobs["3-keycards-BACK-any.pdf"] = doc(CARD_CSS, back_sheet("Key card backs · print on the reverse of any key card sheet (flip on the long edge)"))
spots = [f"{i:02d}" for i in range(1, SPOTS + 1)]
jobs[f"4-public-keycards-{SPOTS}-spots-FRONT.pdf"] = doc(CARD_CSS, "".join(
    card_sheet([f"c{s}"] * 9, f"Public spot {s}: 9 key cards, code C{s} · leave with counter letter L{s} · write where you left them in the tracker") for s in spots))
jobs[f"5-public-counter-letters-{SPOTS}.pdf"] = doc(COUNTER_CSS, "".join(counter(f"l{s}") for s in spots))

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    for name, h in jobs.items():
        f = f"{D}/mail/_v2.html"; open(f, "w").write(h)
        pg.goto(f"file://{f}"); pg.wait_for_timeout(500)
        pg.pdf(path=f"{OUT}/{name}", prefer_css_page_size=True, print_background=True)
    b.close()
print(sorted(os.listdir(OUT)))
