"""v3 print set: on-point copy (no wifi hook). Mail letters + key cards, and per-spot pieces in several options.
Codes: m01-m30 mail letters; c01-c41 cards left at a spot; l01-l41 flyer/tent/poster left at a spot."""
import csv, os, html, sys, json, re
sys.path.insert(0, "/tmp/kt")
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/pw-browsers"
import restyle, qrcode, qrcode.image.svg
from playwright.sync_api import sync_playwright

D = "/tmp/kt"; OUT = "/tmp/kt/out3"; os.makedirs(OUT, exist_ok=True)
mail = list(csv.DictReader(open(f"{D}/mail/mail-30.csv", encoding="utf-8")))
spots = json.load(open(f"{D}/mail/spots_final.json", encoding="utf-8"))
ONLY = os.environ.get("ONLY")  # build a subset while testing
esc = html.escape

def tag_svg(code, label=True):
    s = restyle.restyle("tag-yellow", f"https://keegix.com/demo?src={code}")
    if label:
        s = s.replace("</svg>",
            f'<text x="19" y="46.6" text-anchor="middle" font-family="Archivo" font-weight="800" font-size="3.1" style="font-stretch:118%" fill="#15304a">keegix.com</text>'
            f'<text x="19" y="51.2" text-anchor="middle" font-family="Archivo" font-weight="700" font-size="2.1" letter-spacing=".25" fill="#15304a">{code.upper()}</text></svg>')
    return s.replace("<svg ", '<svg style="width:100%;height:100%;display:block" ', 1)

def plain_qr(url):
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, border=0, error_correction=qrcode.constants.ERROR_CORRECT_M)
    s = img.to_string(encoding="unicode")
    s = re.sub(r'width="[^"]*"', 'width="100%"', s, count=1); s = re.sub(r'height="[^"]*"', 'height="100%"', s, count=1)
    return s

FONTS = f"""
@font-face{{font-family:'Archivo';font-weight:400 800;font-stretch:62% 125%;src:url(file://{D}/fonts/Archivo-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:normal;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:italic;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-italic.woff2) format('woff2')}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Archivo,sans-serif;color:#15304A;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
@page{{size:8.5in 11in;margin:0}}
.page{{width:8.5in;height:11in;position:relative;overflow:hidden;page-break-after:always}}
.kick{{font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-stretch:125%}}
.serif{{font-family:Newsreader,serif;font-weight:500;letter-spacing:-.02em}}
.yel{{color:#F4C430}}
"""
WHAT = "One guest page for each property, opened from a QR sign by the door: check-in steps, parking, house rules, local picks and the checkout list. Change it once and every guest sees the update. Nothing to reprint, no app for guests."
OFFER = "Founding hosts in Nova Scotia get Pro free until the end of 2027."
OFFER2 = "No card, no call. I'll build it from your notes if you'd rather not."

# ---------------- mail letter (#10 window, address in the safe zone) ----------------
LETTER_CSS = """
.logo{position:absolute;left:1in;top:.6in;width:1.15in}
.code{position:absolute;right:.6in;top:.62in;font-size:7.5pt;color:#9aa7b0;letter-spacing:.06em}
.addr{position:absolute;left:1.05in;top:2.55in;width:3.9in;font-size:10.5pt;line-height:1.28}
.addr b{font-weight:700}
.fold{position:absolute;width:.25in;border-top:1px solid #d3dcda}
.body{position:absolute;left:1in;top:4.0in;width:4.6in;font-size:10.6pt;line-height:1.45}
.body p{margin-bottom:.11in}
.body .hi{font-family:Newsreader,serif;font-weight:500;font-size:14.5pt;margin-bottom:.09in}
.body b{font-weight:700}
.sig{font-size:9.6pt;color:#4E5C66;margin-top:.12in}
.sig .nm{font-family:Newsreader,serif;font-style:italic;font-size:13.5pt;color:#15304A}
.slot{position:absolute;left:5.9in;top:7.52in;width:2.2in;height:3.37in;border:1.2px dashed #c3ccd2;border-radius:.12in;display:flex;align-items:center;justify-content:center;text-align:center;font-size:7.5pt;color:#9aa7b0;padding:.2in}
"""
def letter(r):
    n = esc(r["name"])
    return f"""<div class="page"><img class="logo" src="file://{D}/logo-lockup-navy.png"><div class="code">{r['code'].upper()}</div>
  <div class="addr"><b>{n}</b><br>{esc(r['address1'])}<br>{esc(r['city'])} {r['province']}&nbsp;&nbsp;{r['postcode']}</div>
  <div class="fold" style="left:.25in;top:3.667in"></div><div class="fold" style="right:.25in;top:3.667in"></div>
  <div class="fold" style="left:.25in;top:7.333in"></div><div class="fold" style="right:.25in;top:7.333in"></div>
  <div class="body">
    <p class="hi">Hi everyone at {n},</p>
    <p>I'm Vatsal, from Kentville. I built Keegix: one guest page for each of your units, opened from a QR sign by the door. Check-in steps, parking, house rules, local picks and the checkout list sit in one place on the guest's phone. Change it once and every guest sees the update.</p>
    <p><b>Founding hosts in Nova Scotia get Pro free until the end of 2027.</b> No card, no call. If you'd rather not set it up yourself, send me what you already give guests and I'll build it for you.</p>
    <p>If you list on Airbnb: its new house rules policy starts November 20. Keegix flags checkout chores the policy no longer allows.</p>
    <p>The key card with this letter opens a sample guest page. Claim your spot at <b>keegix.com/founding</b>.</p>
    <p class="sig">Thanks,<br><span class="nm">Vatsal Thakkar</span><br>Keegix · contact@keegix.com</p>
  </div>
  <div class="slot">Tape key card {r['code'].upper()} here</div></div>"""

# ---------------- key cards 2.2 x 3.37 (9 per sheet) ----------------
CW, CH = 2.2, 3.37; GX = (8.5 - 3*CW)/2; GY = (11 - 3*CH)/2
CARD_CSS = f"""
.card{{position:absolute;width:{CW}in;height:{CH}in}}
.foot{{position:absolute;bottom:.12in;width:100%;text-align:center;font-size:7pt;color:#9aa7b0}}
.back{{display:flex;flex-direction:column;align-items:center;text-align:center;padding:.55in .2in 0}}
.back img{{width:1.05in;margin-bottom:.12in}}
.back .l1{{font-family:Newsreader,serif;font-weight:500;font-size:10.2pt;line-height:1.15;margin-bottom:.1in}}
.back .l2{{font-size:7.2pt;font-weight:700;line-height:1.3;margin-bottom:.06in}}
.back .l3{{font-size:6.6pt;color:#4E5C66;line-height:1.3}}
"""
def cpos(i): return GX + (i % 3)*CW, GY + (i // 3)*CH
def keycard_sheet(codes, note):
    return '<div class="page">' + "".join(f'<div class="card" style="left:{cpos(i)[0]}in;top:{cpos(i)[1]}in">{tag_svg(c)}</div>' for i, c in enumerate(codes)) + f'<div class="foot">{note}</div></div>'
def keycard_back():
    b = (f'<div class="back"><img src="file://{D}/logo-lockup-navy.png"><div class="l1">One guest page per property, opened from a QR sign by the door.</div>'
         f'<div class="l2">Founding hosts: Pro free until the end of 2027. No card.</div><div class="l3">keegix.com/founding</div></div>')
    return '<div class="page">' + "".join(f'<div class="card" style="left:{cpos(i)[0]}in;top:{cpos(i)[1]}in">{b}</div>' for i in range(9)) + '<div class="foot">Key card backs: print on the reverse of any key card sheet (flip on the long edge)</div></div>'

# ---------------- business cards 3.5 x 2 (10 per sheet) — option B card, from the old B09 card ----------------
BW, BH = 3.5, 2.0; BX = (8.5 - 2*BW)/2; BY = (11 - 5*BH)/2
BIZ_CSS = f"""
.biz{{position:absolute;width:{BW}in;height:{BH}in;background:#15304A;color:#fff;padding:.2in .22in}}
.biz .k{{font-size:6.3pt;color:#F4C430}}
.biz .h{{font-family:Newsreader,serif;font-weight:500;font-size:11.5pt;line-height:1.08;margin-top:.05in;width:1.9in}}
.biz .h em{{font-style:italic;color:#F4C430}}
.biz .o{{position:absolute;left:.22in;bottom:.42in;width:1.9in;font-size:6.6pt;line-height:1.3;color:#E3ECE9}}
.biz .u{{position:absolute;left:.22in;bottom:.18in;font-size:8.5pt;font-weight:800;font-stretch:118%}}
.biz .q{{position:absolute;right:.16in;top:.16in;width:1.09in;height:1.67in}}
.crop{{position:absolute;background:#9aa7b0}}
.bback{{position:absolute;width:{BW}in;height:{BH}in;background:#fff;display:flex;flex-direction:column;justify-content:center;padding:0 .3in}}
.bback img{{width:1.1in;margin-bottom:.1in}}
.bback .t{{font-size:7.6pt;line-height:1.35;color:#4E5C66}}
"""
def bpos(i): return BX + (i % 2)*BW, BY + (i // 2)*BH
def crops():
    m = []
    for x in [BX, BX+BW, BX+2*BW]:
        m.append(f'<div class="crop" style="left:{x}in;top:{BY-.35}in;width:.6pt;height:.25in"></div><div class="crop" style="left:{x}in;top:{BY+5*BH+.1}in;width:.6pt;height:.25in"></div>')
    for k in range(6):
        y = BY + k*BH
        m.append(f'<div class="crop" style="left:{BX-.35}in;top:{y}in;width:.25in;height:.6pt"></div><div class="crop" style="left:{BX+2*BW+.1}in;top:{y}in;width:.25in;height:.6pt"></div>')
    return "".join(m)
def biz_sheet(code, note):
    card = (f'<div class="kick k">For hosts in Nova Scotia</div><div class="h">Rent out a cottage, room or cabin? <em>Scan me.</em></div>'
            f'<div class="o">One guest page + QR sign per property. Founding hosts: Pro free until the end of 2027.</div><div class="u">keegix.com</div><div class="q">{tag_svg(code)}</div>')
    return '<div class="page">' + "".join(f'<div class="biz" style="left:{bpos(i)[0]}in;top:{bpos(i)[1]}in">{card}</div>' for i in range(10)) + crops() + f'<div class="foot">{note}</div></div>'
def biz_back():
    b = (f'<img src="file://{D}/logo-lockup-navy.png"><div class="t">{WHAT}</div>')
    return '<div class="page">' + "".join(f'<div class="bback" style="left:{bpos(i)[0]}in;top:{bpos(i)[1]}in">{b}</div>' for i in range(10)) + '<div class="foot">Business card backs: print on the reverse (flip on the long edge)</div></div>'

# ---------------- flyer option 1: poster (from the old B01 poster) ----------------
POSTER_CSS = """
.p1{background:#15304A;color:#fff}
.p1 .k{position:absolute;left:.85in;top:.85in;font-size:10pt;color:#F4C430}
.p1 .h{position:absolute;left:.85in;top:1.15in;width:6.8in;font-size:58pt;line-height:.98}
.p1 .h em{font-style:italic;color:#F4C430}
.p1 .w{position:absolute;left:.85in;top:3.55in;width:6.6in;font-size:13pt;line-height:1.45;color:#E3ECE9}
.p1 .tag{position:absolute;left:.85in;top:5.2in;width:2.35in;height:3.6in}
.p1 .o{position:absolute;left:3.6in;top:5.55in;width:4.1in}
.p1 .o .ok{font-size:9pt;color:#F4C430}
.p1 .o .oh{font-family:Newsreader,serif;font-size:24pt;line-height:1.08;margin-top:.08in}
.p1 .o .ot{font-size:11pt;color:#E3ECE9;margin-top:.15in;line-height:1.4}
.p1 .o .ou{font-size:15pt;font-weight:800;font-stretch:118%;margin-top:.2in}
.p1 .f{position:absolute;left:.85in;right:.85in;bottom:.6in;border-top:1px solid rgba(255,255,255,.2);padding-top:.18in;display:flex;justify-content:space-between;align-items:center;font-size:9pt;color:#C9D4D0}
.p1 .f img{width:1.3in}
"""
def poster(code):
    return f"""<div class="page p1"><div class="kick k">For hosts in Nova Scotia</div>
  <div class="serif h">Let the house <em>answer the questions.</em></div>
  <div class="w">{WHAT}</div>
  <div class="tag">{tag_svg(code)}</div>
  <div class="o"><div class="kick ok">Scan to see a sample</div><div class="oh">{OFFER}</div><div class="ot">{OFFER2}</div><div class="ou">keegix.com/founding</div></div>
  <div class="f"><img src="file://{D}/logo-lockup-white.png"><span>Made in Kentville, Nova Scotia · {code.upper()}</span></div></div>"""

# ---------------- flyer option 2: table tent (from the old B11 tent) ----------------
TENT_CSS = """
.tent{background:#15304A;color:#fff}
.half{position:absolute;left:0;width:8.5in;height:5.5in}
.half.top{top:0;transform:rotate(180deg)}.half.bot{top:5.5in}
.tfold{position:absolute;left:0;right:0;top:5.5in;border-top:1px dashed rgba(255,255,255,.35)}
.half .lg{position:absolute;left:.7in;top:.55in;width:1.25in}
.half .k{position:absolute;left:.7in;top:1.25in;font-size:9pt;color:#F4C430}
.half .h{position:absolute;left:.7in;top:1.5in;width:4.3in;font-size:40pt;line-height:1}
.half .h em{font-style:italic;color:#F4C430}
.half .t{position:absolute;left:.7in;top:3.55in;width:4.3in;font-size:11.5pt;line-height:1.4;color:#E3ECE9}
.half .q{position:absolute;right:.7in;top:.6in;width:2.45in;height:3.75in}
.half .u{position:absolute;right:.7in;top:4.5in;width:2.45in;text-align:center;font-size:12pt;font-weight:800;font-stretch:118%}
"""
def tent_half(code, cls):
    return (f'<div class="half {cls}"><img class="lg" src="file://{D}/logo-lockup-white.png"><div class="kick k">Hosts &amp; property managers</div>'
            f'<div class="serif h">Hosting? <em>Scan me.</em></div><div class="t">One guest page + QR sign per property. {OFFER} No card.</div>'
            f'<div class="q">{tag_svg(code)}</div><div class="u">keegix.com/founding</div></div>')
def tent(code):
    return f'<div class="page tent">{tent_half(code, "top")}<div class="tfold"></div>{tent_half(code, "bot")}</div>'

# ---------------- flyer option 3: tear-off poster (from the old B05, new headline) ----------------
TEAR_CSS = """
.tear{background:#F3F5F2}
.tear .lg{position:absolute;left:.75in;top:.7in;background:#fff;border-radius:.12in;padding:.14in .22in}
.tear .lg img{width:1.35in;display:block}
.tear .k{position:absolute;left:.75in;top:1.65in;font-size:9.5pt;color:#9a7300}
.tear .h{position:absolute;left:.75in;top:1.92in;width:7in;font-size:44pt;line-height:1.02}
.tear .h em{font-style:italic}
.tear .sub{position:absolute;left:.75in;top:3.55in;width:7in;font-size:20pt;color:#9a7300}
.tear .t{position:absolute;left:.75in;top:4.1in;width:6.9in;font-size:12.5pt;line-height:1.45;color:#2b3f52}
.tear .tag{position:absolute;left:.75in;top:5.25in;width:2.0in;height:3.06in}
.tear .s{position:absolute;left:3.15in;top:6.05in}
.tear .s .sk{font-size:9pt;color:#9a7300}
.tear .s .su{font-family:Newsreader,serif;font-size:26pt;margin-top:.06in}
.tear .s .sc{font-size:8pt;color:#9aa7b0;margin-top:.1in}
.tabs{position:absolute;left:0;right:0;top:8.45in;bottom:0;border-top:1.5px dashed #9aa7b0;display:flex;background:#fff}
.tab{flex:1;border-right:1px dashed #c3ccd2;position:relative}
.tab:last-child{border-right:none}
.tab .v{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%) rotate(-90deg);white-space:nowrap;text-align:center}
.tab .v b{display:block;font-size:10.5pt;font-weight:800;font-stretch:118%}
.tab .v span{font-size:7pt;color:#4E5C66}
"""
def tear(code):
    tabs = "".join('<div class="tab"><div class="v"><b>keegix.com/founding</b><span>Pro free to end of 2027</span></div></div>' for _ in range(8))
    return f"""<div class="page tear"><div class="lg"><img src="file://{D}/logo-lockup-navy.png"></div>
  <div class="kick k">Airbnb, cottage &amp; rental hosts</div>
  <div class="serif h">Rent out a cottage, room or cabin?</div><div class="serif sub"><em>Founding hosts get Pro free until the end of 2027.</em></div>
  <div class="t">{WHAT} No card, no call.</div>
  <div class="tag">{tag_svg(code)}</div>
  <div class="s"><div class="kick sk">Scan, or tear one off</div><div class="su">keegix.com/founding</div><div class="sc">{code.upper()}</div></div>
  <div class="tabs">{tabs}</div></div>"""

# ---------------- flyer option 4: Airbnb house rules news (timely) ----------------
NEWS_CSS = """
.news{background:#fff}
.news .band{position:absolute;left:0;right:0;top:0;height:.55in;background:#F4C430;display:flex;align-items:center;padding-left:.8in;font-size:9.5pt}
.news .k{position:absolute;left:.8in;top:1.05in;font-size:9.5pt;color:#4E5C66}
.news .h{position:absolute;left:.8in;top:1.32in;width:6.9in;font-size:46pt;line-height:1.0}
.news .h em{font-style:italic;color:#9a7300}
.news .t{position:absolute;left:.8in;top:3.75in;width:4.0in;font-size:12pt;line-height:1.48;color:#2b3f52}
.news .t p{margin-bottom:.14in}
.news .t b{color:#15304A}
.news .qb{position:absolute;left:5.25in;top:3.8in;width:2.45in;background:#15304A;border-radius:.16in;padding:.25in;color:#fff;text-align:center}
.news .qb .qq{background:#fff;border-radius:.1in;padding:.13in;width:1.95in;height:1.95in}
.news .qb .qq svg path{fill:#15304A}
.news .qb .ql{font-size:10pt;font-weight:700;margin-top:.15in;line-height:1.3}
.news .qb .qu{font-size:8pt;color:#C9D4D0;margin-top:.06in}
.news .src{position:absolute;left:.8in;bottom:1.25in;width:6.9in;font-size:7.5pt;color:#9aa7b0}
.news .f{position:absolute;left:.8in;right:.8in;bottom:.6in;border-top:1px solid #d3dcda;padding-top:.16in;display:flex;justify-content:space-between;align-items:center;font-size:9pt;color:#4E5C66}
.news .f img{width:1.25in}
"""
def news(code):
    url = f"https://keegix.com/airbnb-house-rules?src={code}"
    return f"""<div class="page news"><div class="band kick">Heads up for Airbnb hosts</div>
  <div class="kick k">Starts November 20, 2026</div>
  <div class="serif h">Airbnb's new house rules: <em>is your checkout list still allowed?</em></div>
  <div class="t"><p>Airbnb's new policy says guests shouldn't be asked to do a cleaner's job at checkout: washing dishes, stripping beds, starting laundry or taking garbage off-site.</p>
  <p><b>Check your list free, no sign-up.</b> Paste it in and see what gets flagged, with an allowed version for each chore.</p>
  <p>Keegix also gives each property one guest page and a QR sign by the door. {OFFER}</p></div>
  <div class="qb"><div class="qq">{plain_qr(url)}</div><div class="ql">Scan to check your checkout list</div><div class="qu">keegix.com/airbnb-house-rules</div></div>
  <div class="src">Based on Airbnb's house rules announcement to hosts (October 2026). Check Airbnb's help centre for the full policy.</div>
  <div class="f"><img src="file://{D}/logo-lockup-navy.png"><span>Made in Kentville, Nova Scotia · {code.upper()}</span></div></div>"""

def doc(css, body):
    return f'<html><head><meta charset="utf-8"><style>{FONTS}{css}</style></head><body>{body}</body></html>'

S = spots if not ONLY else spots[:int(ONLY)]
jobs = {
 "01-mail-letters-30.pdf": doc(LETTER_CSS, "".join(letter(r) for r in mail)),
 "02-mail-keycards-30-FRONT.pdf": doc(CARD_CSS, "".join(keycard_sheet([r["code"] for r in mail][i:i+9], "Mail key cards: match each card number to its letter · cardstock · print at 100% (Actual size) · cut along the yellow shape") for i in range(0, len(mail), 9))),
 "03-keycards-BACK.pdf": doc(CARD_CSS, keycard_back()),
 "10-CARD-option-A-keycards-per-spot.pdf": doc(CARD_CSS, "".join(keycard_sheet([s["cards"]]*9, f"Spot {s['n']}: {esc(s['name'])} ({esc(s['town'])}) · 9 key cards, code {s['cards'].upper()}") for s in S)),
 "11-CARD-option-B-business-cards-per-spot.pdf": doc(BIZ_CSS + CARD_CSS, "".join(biz_sheet(s["cards"], f"Spot {s['n']}: {esc(s['name'])} ({esc(s['town'])}) · 10 cards, code {s['cards'].upper()} · cut on the grey marks") for s in S)),
 "12-business-cards-BACK.pdf": doc(BIZ_CSS + CARD_CSS, biz_back()),
 "20-FLYER-option-1-poster-per-spot.pdf": doc(POSTER_CSS, "".join(poster(s["flyer"]) for s in S)),
 "21-FLYER-option-2-table-tent-per-spot.pdf": doc(TENT_CSS, "".join(tent(s["flyer"]) for s in S)),
 "22-FLYER-option-3-tearoff-per-spot.pdf": doc(TEAR_CSS, "".join(tear(s["flyer"]) for s in S)),
 "23-FLYER-option-4-airbnb-rules-per-spot.pdf": doc(NEWS_CSS, "".join(news(s["flyer"]) for s in S)),
}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    for name, h in jobs.items():
        f = f"{D}/mail/_v3.html"; open(f, "w").write(h)
        pg.goto(f"file://{f}"); pg.wait_for_timeout(600)
        pg.pdf(path=f"{OUT}/{name}", prefer_css_page_size=True, print_background=True)
    b.close()
print(sorted(x for x in os.listdir(OUT) if x.endswith(".pdf")))
