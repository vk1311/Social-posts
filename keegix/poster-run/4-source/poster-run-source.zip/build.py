import os, re
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/pw-browsers"
from playwright.sync_api import sync_playwright

D = "/tmp/kt"
OUT = "/tmp/kt/out"
os.makedirs(OUT, exist_ok=True)

def qr(name):
    s = open(f"{D}/{name}").read()
    s = re.sub(r"<\?xml.*?\?>", "", s)
    s = re.sub(r'width="[^"]*"', 'width="100%"', s, count=1)
    s = re.sub(r'height="[^"]*"', 'height="100%"', s, count=1)
    return s

QR_TAG = qr("qr-keytag.svg")
QR_CARD = qr("qr-postcard.svg")

def style(name):
    s = open(f"{D}/qr/{name}.svg").read()
    return s.replace("<svg ", '<svg style="height:100%;width:auto;max-width:100%;display:block" ', 1)

TAG_STYLES = ["tag-yellow", "house", "door", "bubble", "circle", "square"]

FONTS = f"""
@font-face{{font-family:'Archivo';font-weight:400 800;font-stretch:62% 125%;src:url(file://{D}/fonts/Archivo-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:normal;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-normal.woff2) format('woff2')}}
@font-face{{font-family:'Newsreader';font-style:italic;font-weight:400 600;src:url(file://{D}/fonts/Newsreader-italic.woff2) format('woff2')}}
:root{{--navy:#15304A;--deep:#0E2236;--yellow:#F4C430;--sea:#E3ECE9;--slate:#4E5C66;--rule:#D3DCDA}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:Archivo,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
.kick{{font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-stretch:125%}}
.serif{{font-family:Newsreader,serif;font-weight:500;letter-spacing:-.025em;line-height:1.02}}
"""

# ---------- KEYTAG (2.5in x 4.25in, shape = the Keegix mark) ----------
SHAPE = "M25,0 H225 A25,25 0 0 1 250,25 V300 L125,425 L0,300 V25 A25,25 0 0 1 25,0 Z"

def tag_front(st="tag-yellow", prefix="cafe", kicker="Hosting in the Valley?"):
    return f"""
<div class="tag">
  <svg class="shape" viewBox="0 0 250 425"><path d="{SHAPE}" fill="#15304A" stroke="#9aa7b0" stroke-width=".6"/>
    <circle cx="125" cy="42" r="19" fill="#F4C430"/><circle cx="125" cy="42" r="12.5" fill="#fff"/>
    <path d="M121,42h8M125,38v8" stroke="#9aa7b0" stroke-width=".6"/></svg>
  <div class="in front">
    <div class="kick k">{kicker}</div>
    <div class="serif h">Let the house <em>answer the questions.</em></div>
    <div class="sty">{style(prefix + "-" + st)}</div>
    <div class="scan">Scan to open a sample cottage</div>
    <div class="url">keegix.com</div>
  </div>
</div>"""

def tag_back():
    return f"""
<div class="tag">
  <svg class="shape" viewBox="0 0 250 425"><path d="{SHAPE}" fill="#ffffff" stroke="#9aa7b0" stroke-width=".6"/>
    
    <circle cx="125" cy="42" r="19" fill="none" stroke="#F4C430" stroke-width="3"/>
    <path d="M121,42h8M125,38v8" stroke="#9aa7b0" stroke-width=".6"/></svg>
  <div class="in back">
    <img class="lock" src="file://{D}/logo-lockup-navy.png">
    <div class="serif bh">A welcome book your guests open on their phone.</div>
    <ul>
      <li>Wifi, check-in, house rules, checkout</li>
      <li>One guest link + a QR sign for the door</li>
      <li>Edit once. Nothing to reprint.</li>
    </ul>
    <div class="price">
      <div class="p1">Founding hosts get Pro<br>free until the end of 2027.</div>
      <div class="p2">No card. Free plan forever after. Scan the front to see a sample cottage.</div>
    </div>
    <div class="made">Made in Nova Scotia</div>
    <div class="mail">contact@keegix.com</div>
  </div>
</div>"""

TAG_CSS = """
@page{size:8.5in 11in;margin:0}
.sheet{width:8.5in;height:11in;position:relative;page-break-after:always;overflow:hidden}
.grid{position:absolute;left:.5in;top:1.25in;display:grid;grid-template-columns:repeat(3,2.5in);grid-template-rows:repeat(2,4.25in)}
.tag{width:2.5in;height:4.25in;position:relative}
.shape{position:absolute;inset:0;width:100%;height:100%}
.in{position:absolute;inset:0;text-align:center}
.front .k{position:absolute;top:.72in;width:100%;font-size:6.6pt;color:#E3ECE9}
.front .h{position:absolute;top:.87in;left:.22in;right:.22in;font-size:15.5pt;color:#fff}
.front .h em{color:#F4C430;font-style:italic}
.sty{position:absolute;top:1.5in;left:.15in;right:.15in;height:1.65in;display:flex;justify-content:center}
.qrbox{position:absolute;top:1.62in;left:.55in;width:1.4in;height:1.4in;background:#fff;border-radius:.1in;padding:.11in}
.qrbox svg path{fill:#15304A}
.scan{position:absolute;top:3.25in;width:100%;font-size:6.6pt;color:#E3ECE9;font-weight:500}
.url{position:absolute;top:3.4in;width:100%;font-size:11pt;font-weight:800;font-stretch:118%;color:#F4C430}
.back .lock{position:absolute;top:.72in;left:.6in;width:1.3in}
.back .bh{position:absolute;top:1.25in;left:.2in;right:.2in;font-size:12.5pt;color:#15304A}
.back ul{position:absolute;top:1.92in;left:.26in;right:.2in;list-style:none;text-align:left;font-size:7pt;color:#4E5C66;line-height:1.55}
.back li:before{content:"";display:inline-block;width:.06in;height:.06in;background:#F4C430;border-radius:50%;margin-right:.07in;vertical-align:1px}
.price{position:absolute;top:2.5in;left:.2in;right:.2in;border-top:1px solid #D3DCDA;padding-top:.08in}
.p1{font-size:8.6pt;font-weight:800;color:#15304A;line-height:1.25}
.p2{font-size:6.4pt;color:#4E5C66;margin-top:.04in;line-height:1.35}
.made{position:absolute;top:3.3in;width:100%;font-size:6pt;color:#15304A;font-weight:700}
.mail{position:absolute;top:3.46in;width:100%;font-size:6pt;color:#4E5C66}
.foot{position:absolute;bottom:.45in;width:100%;text-align:center;font-size:7pt;color:#9aa7b0}
.single .grid{left:0;top:0}
"""

def tag_sheet(kind, note, prefix="cafe", kicker="Hosting in the Valley?"):
    cells = "".join(tag_front(st, prefix, kicker) for st in TAG_STYLES) if kind == "front" else tag_back() * 6
    return f'<div class="sheet"><div class="grid">{cells}</div><div class="foot">{note}</div></div>'

def tag_html(body):
    return f"<html><head><style>{FONTS}{TAG_CSS}</style></head><body>{body}</body></html>"

# ---------- POSTCARD 6x4in + 0.125in bleed ----------
CARD_CSS = """
@page{size:6.25in 4.25in;margin:0}
.card{width:6.25in;height:4.25in;position:relative;overflow:hidden;page-break-after:always}
.cf{background:#15304A}
.cf .k{position:absolute;top:.55in;left:.5in;font-size:7.5pt;color:#E3ECE9}
.cf .h{position:absolute;top:.78in;left:.5in;width:3.1in;font-size:25pt;color:#fff}
.cf .h em{color:#F4C430;font-style:italic}
.cf .sub{position:absolute;top:2.55in;left:.5in;width:2.9in;font-size:8.5pt;color:#E3ECE9;line-height:1.45}
.cf .lock{position:absolute;bottom:.42in;left:.5in;width:1.1in}
.bigtag2{position:absolute;top:.3in;right:.55in;height:3.25in}
.bt{position:absolute;bottom:.3in;right:.4in;width:2.4in;text-align:center;font-size:6.5pt;color:#E3ECE9}
.bigtag{position:absolute;top:.38in;right:.48in;width:2.0in;height:3.4in}
.bigtag svg.s{position:absolute;inset:0;width:100%;height:100%}
.bigtag .q{position:absolute;top:1.15in;left:.36in;width:1.28in;height:1.28in;background:#fff;border-radius:.08in;padding:.1in}
.bigtag .q svg path{fill:#15304A}
.bigtag .u{position:absolute;top:2.6in;width:100%;text-align:center;font-weight:800;font-stretch:118%;font-size:10pt;color:#15304A}
.bigtag .t{position:absolute;top:.62in;width:100%;text-align:center;font-size:6.5pt;color:#15304A}
.cb{background:#fff}
.cb .left{position:absolute;top:.45in;left:.45in;width:2.55in}
.cb .k{font-size:7pt;color:#4E5C66}
.cb .h{font-size:15pt;color:#15304A;margin-top:.06in}
.cb ul{list-style:none;margin-top:.12in;font-size:7.6pt;color:#15304A;line-height:1.6}
.cb li:before{content:"";display:inline-block;width:.07in;height:.07in;background:#F4C430;border-radius:50%;margin-right:.08in;vertical-align:1px}
.cb .price{margin-top:.12in;padding-top:.08in;border-top:1px solid #D3DCDA;font-size:8.4pt;font-weight:800;color:#15304A;line-height:1.3}
.cb .price span{display:block;font-weight:400;font-size:7pt;color:#4E5C66;margin-top:.03in}
.cb .sig{position:absolute;bottom:.4in;left:.45in;font-size:7pt;color:#4E5C66;line-height:1.45}
.cb .sig b{color:#15304A}
.cb .mini{position:absolute;bottom:.32in;left:2.2in;width:.82in;height:.82in}
.cb .clear{position:absolute;top:.125in;right:.125in;width:2.95in;bottom:.125in;border-left:1px dashed #D3DCDA}
.cb .clear.hide{border:none}
"""

def big_tag():
    return f"""<div class="bigtag2">{style("mail-tag-yellow")}</div><div class="kick bt">Scan it like your guest would</div>"""

def card_front():
    return f"""<div class="card cf">
  <div class="kick k">For cottage &amp; Airbnb hosts</div>
  <div class="serif h">The 11:47 PM wifi text? <em>Let the house answer it.</em></div>
  <div class="sub">Keegix is a welcome book your guests open on their phone: wifi, check-in, house rules and checkout, behind one QR sign by the door.</div>
  <img class="lock" src="file://{D}/logo-lockup-white.png">
  {big_tag()}
</div>"""

def card_back(guide):
    return f"""<div class="card cb">
  <div class="left">
    <div class="kick k">Made in Nova Scotia</div>
    <div class="serif h">One link. One sign. Edit once, nothing to reprint.</div>
    <ul><li>Check-in steps and parking</li><li>Wifi with a copy button</li><li>House rules, trash day, local picks</li><li>The checkout list</li></ul>
    <div class="price">Founding hosts: Pro free until the end of 2027.<span>No card, no call. Or send me your notes and I'll build it for you: $39 CAD, one time.</span></div>
  </div>
  <div class="sig"><b>Vatsal, Keegix</b><br>keegix.com/founding<br>contact@keegix.com</div>
  <div class="mini">{style("mail-square")}</div>
  <div class="clear {'' if guide else 'hide'}"></div>
</div>"""

def card_html(body):
    return f"<html><head><style>{FONTS}{CARD_CSS}</style></head><body>{body}</body></html>"

jobs = {
  "keegix-keytags-MAIL-FRONT-letter.pdf": tag_html(tag_sheet("front", "Mailed key tags (src=mtag) · fronts · print at 100% on letter cardstock · backs = the same BACK file", "mtag", "Hosting in Nova Scotia?")),
  "keegix-keytags-FRONT-letter.pdf": tag_html(tag_sheet("front", "Keegix key tags · fronts · print at 100% (Actual size) on letter cardstock · cut on the grey line · punch the circle")),
  "keegix-keytags-BACK-letter.pdf": tag_html(tag_sheet("back", "Keegix key tags · backs · feed the printed sheet back in, flip on the long edge")),
  "keegix-postcard-6x4-FRONT.pdf": card_html(card_front()),
  "keegix-postcard-6x4-BACK.pdf": card_html(card_back(False)),
}
pngs = {
  **{f"preview-keytag-{st}.png": (tag_html(f'<div class="sheet single" style="width:2.5in;height:4.25in"><div class="grid">{tag_front(st)}</div></div>'), 240, 408) for st in TAG_STYLES},
  "preview-keytag-sheet.png": (tag_html(tag_sheet("front", "")), 816, 1056),
  "preview-keytag-back.png": (tag_html(f'<div class="sheet single" style="width:2.5in;height:4.25in"><div class="grid">{tag_back()}</div></div>'), 240, 408),
  "preview-postcard-front.png": (card_html(card_front()), 600, 408),
  "preview-postcard-back.png": (card_html(card_back(True)), 600, 408),
}

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page()
    for name, html in jobs.items():
        f = f"{D}/_tmp.html"; open(f, "w").write(html)
        pg.goto(f"file://{f}"); pg.wait_for_timeout(400)
        pg.pdf(path=f"{OUT}/{name}", prefer_css_page_size=True, print_background=True)
    for name, (html, w, h) in pngs.items():
        pg2 = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=3)
        f = f"{D}/_tmp.html"; open(f, "w").write(html)
        pg2.goto(f"file://{f}"); pg2.wait_for_timeout(400)
        pg2.screenshot(path=f"{OUT}/{name}", clip={"x": 0, "y": 0, "width": w, "height": h}, omit_background=True)
        pg2.close()
    b.close()
print(os.listdir(OUT))
