POSTS = [
 dict(n=1, date='Tue Sep 29', time='7:00 pm', fmt='Reel', kind='Launch', folder='p01-launch-reel', title='Launch: Let the house answer the questions',
  cap="""Keegix is live. 🏡

Every host knows the 11:47 PM buzz. Wifi password. Parking. Which bin goes out. How the shower works.

Keegix puts every answer on one link and one QR sign by the door. Guests open it on their phone. No app, no account.

Free for one property. Link in bio.""",
  fb="""Keegix is live.

If you host a cottage, cabin or short-term rental, you know the 11:47 PM text: "sorry, what's the wifi password again?"

Keegix is a welcome book your guests open on their phone. Check-in steps, wifi, parking, house rules, trash day, local picks and the checkout list, all on one link, plus a printable QR sign for the door. Guests don't need an app or an account, and when something changes you edit it once. Nothing to reprint.

Free for one property, no card needed: keegix.com
Made in Nova Scotia.""",
  tags='#shorttermrental #airbnbhost #vacationrental #cottagelife #novascotia #capebreton #strhost #guestexperience #hosttips',
  alt='Short video: a phone fills with guest texts at 11:47 PM, a guest scans a QR sign by a cottage door, a phone shows the Keegix welcome book with check-in, wifi and checkout, and the Keegix logo with the line "Let the house answer the questions."',
  first='What’s the question your guests ask most? Mine is the wifi, every time.'),
 dict(n=2, date='Thu Oct 1', time='7:00 pm', fmt='Carousel (7)', kind='Product explainer', folder='p02-what-is-keegix', title='What is Keegix?',
  cap="""Your guests have questions. Let the house answer them. 👉

Keegix in 7 slides:
• one link for everything guests text you about
• a QR sign for the door
• edit once, nothing to reprint

Free for one property. keegix.com""",
  fb="""Here's the whole idea in seven slides.

Hosts answer the same questions one text at a time, often at night. Keegix puts check-in, wifi, parking, house rules, trash day, local picks and the checkout list on one link you paste into your booking message, plus a letter-size QR sign for the door.

Change the wifi password? Edit it once. The link and the sign stay the same.

Free for one property. $9 CAD per property per month for more. keegix.com""",
  tags='#shorttermrental #airbnbtips #vacationrentalhost #welcomebook #housemanual #guestexperience #novascotia',
  alt='Carousel explaining Keegix: a cottage porch, guest text messages, a phone showing the guest page, a list of sections, a QR sign framed on a door, a changed wifi password, and pricing.',
  first='Save this for when you set up your next listing.'),
 dict(n=3, date='Sat Oct 3', time='10:00 am', fmt='Single image', kind='Humour', folder='p03-1147pm', title='11:47 PM',
  cap="""11:47 PM. You know who it is. 📱

Put it on the QR sign. Go back to sleep.

keegix.com""",
  fb="""11:47 PM. "Hey so sorry to bug you, what's the wifi password again?"

Put it on the QR sign. Go back to sleep. 😴

keegix.com""",
  tags='#airbnbhost #hostlife #shorttermrental #hostproblems #vacationrental #strhost',
  alt='A phone lock screen reading 11:47 with three texts from a guest asking for the wifi password, which bin goes out and whether they can park on the grass. Text below: Put it on the QR sign. Go back to sleep.',
  first='Tag a host who has answered this exact text.'),
 dict(n=4, date='Tue Oct 6', time='7:00 pm', fmt='Reel', kind='Me vs them', folder='p04-binder-vs-keegix-reel', title='The binder vs. Keegix',
  cap="""The binder vs. Keegix. Four rounds, honest scoring. 📒🥊📱

(The binder wins one. We respect the binder.)

Final score in the video.""",
  fb="""The welcome binder vs. Keegix. Four rounds, honest scoring.

Round 1: the wifi password changed
Round 2: the guest arrives at midnight
Round 3: no signal at the cottage (the binder takes this one, fair)
Round 4: morning coffee

Keep the binder. It makes a great doorstop. keegix.com""",
  tags='#shorttermrental #airbnbhost #vacationrental #hosttips #cottagelife #welcomebook',
  alt='Split-screen video comparing a paper welcome binder with the Keegix guest page over four rounds: a changed wifi password, a midnight arrival, no signal, and a coffee spill. Final score Keegix 4, Binder 1.',
  first='Be honest: is your binder still in the kitchen drawer?'),
 dict(n=5, date='Thu Oct 8', time='7:00 pm', fmt='Carousel (7)', kind='Info', folder='p05-10-things-welcome-book', title='10 things every welcome book needs',
  cap="""10 things every welcome book needs. Save this one. 📌

Short, specific, and on the guest’s phone. Number 9 is the one most hosts forget.""",
  fb="""10 things every welcome book needs:

1. Check-in steps, with a photo
2. Wifi name and password
3. Where to park, and where not to
4. The fussy appliance
5. Trash and recycling day
6. House rules, kept short
7. Emergency contacts
8. Your local picks
9. A plan for no signal
10. A short checkout list

All ten are already sections in Keegix. Free for one property: keegix.com""",
  tags='#airbnbtips #hosttips #shorttermrental #vacationrentaltips #welcomebook #housemanual #superhost',
  alt='Carousel listing 10 things every welcome book needs, from check-in steps with a photo to a short checkout list, each with an example.',
  first='Which one is missing from yours?'),
 dict(n=6, date='Sat Oct 10', time='10:00 am', fmt='Single image', kind='Seasonal humour', folder='p06-thanksgiving', title='Thanksgiving weekend',
  cap="""Thanksgiving weekend guests? The house has the answers. 🍂

(The turkey is still your problem.)

Happy Thanksgiving from Nova Scotia.""",
  fb="""A full house of guests this Thanksgiving weekend? The house has the answers. The turkey is still your problem. 🦃

Happy Thanksgiving from Nova Scotia.""",
  tags='#thanksgiving #canadianthanksgiving #novascotia #cottagelife #shorttermrental #airbnbhost',
  alt='A grey-shingled Nova Scotia cottage with a gravel drive and stone wall. Text: Thanksgiving weekend. A full house of guests? The house has the answers. The turkey is still your problem.',
  first='Happy Thanksgiving, hosts. Hope your guests find the extra blankets.'),
 dict(n=7, date='Tue Oct 13', time='7:00 pm', fmt='Reel', kind='Product how-to', folder='p07-setup-reel', title='How long does a welcome book take?',
  cap="""How long does a welcome book take? About one coffee. ☕

1. Fill in your property
2. Share the link
3. Print the QR sign

Edit it any time. Never reprint.""",
  fb="""How long does it take to set up a Keegix welcome book? About one coffee.

1. Fill in your property from your phone or computer, and add photos from your camera roll.
2. Paste the link into your booking message.
3. Download the letter-size QR sign for the door or the fridge.

Edits show up without reprinting. Free for one property: keegix.com""",
  tags='#shorttermrental #airbnbhost #vacationrental #hosttips #welcomebook #strhost',
  alt='Video: a host lifts a phone at a kitchen table, a phone editor fills in check-in steps, wifi and photos, a booking message with the guest link, and a Keegix QR sign printed and framed on a door.',
  first='Want me to set it up for you instead? That’s the $39 option. Details at keegix.com'),
 dict(n=8, date='Thu Oct 15', time='7:00 pm', fmt='Carousel (5)', kind='Me vs them', folder='p08-binder-pdf-link', title='The binder, the PDF, or the link?',
  cap="""The binder, the PDF, or the link? An honest comparison. 👉

The binder wins a round. We said honest.""",
  fb="""Paper binder, PDF by email, or a link? We scored all three on six things that matter to guests.

The binder wins on no-signal (fair). Keegix covers that one too: guests can save the guide as a PDF before they lose bars.

And versus the other guidebook apps: some come as part of a bigger system you have to adopt first. Keegix does one job, starts free, no card. keegix.com""",
  tags='#shorttermrental #airbnbhost #vacationrentalhost #welcomebook #hosttips #digitalguidebook',
  alt='Carousel comparing a welcome binder, a PDF sent by email and Keegix across six rows, including reading before arrival, updating the wifi, no signal, copying the password, photos and coffee spills.',
  first='Binder, PDF or link: what are you using right now?'),
 dict(n=9, date='Sat Oct 17', time='10:00 am', fmt='Carousel (7)', kind='Product features', folder='p09-5-small-things', title='5 small things guests notice',
  cap="""5 small things guests notice. None are big. All of them save you a text. ✨

All on the free plan.""",
  fb="""Five small things your guests will notice:

1. A copy button on the wifi password
2. A wifi QR code so the laptop joins too
3. "Open in Maps" on any address
4. Save as PDF for places with no signal
5. An optional guest password to keep door codes private

Every one is on the free plan. keegix.com""",
  tags='#guestexperience #shorttermrental #airbnbtips #vacationrental #hosttips #cottagelife',
  alt='Carousel of five close-ups of the Keegix guest page: wifi copy buttons, a wifi QR code, an Open in Maps button, a Save as PDF card and a guest password screen.',
  first='Which one would your guests use first?'),
 dict(n=10, date='Tue Oct 20', time='7:00 pm', fmt='Reel', kind='Humour', folder='p10-1am-thermostat-reel', title='POV: 1:04 AM, the thermostat',
  cap="""POV: it’s 1:04 AM and your guest found the thermostat. 🥶

Let’s try that again.""",
  fb="""POV: it's 1:04 AM and your guest has found the thermostat. Four buttons. None of them work. It's 14 degrees.

Put the fussy stuff in the Appliances section, with a photo. Then enjoy the silence. keegix.com""",
  tags='#hostlife #airbnbhost #shorttermrental #hostproblems #vacationrental #cottagelife',
  alt='Video: late-night guest texts about a confusing thermostat, a rewind, then the Keegix Appliances section with a thermostat photo and steps, and a silent phone at 1:04 AM.',
  first='What’s the fussy appliance at your place?'),
 dict(n=11, date='Thu Oct 22', time='7:00 pm', fmt='Carousel (6)', kind='Info', folder='p11-checkout-list', title='The checkout list guests actually follow',
  cap="""The checkout list guests actually follow. Template inside. 📋

Rule one: five steps. Maybe six.""",
  fb="""A checkout list guests actually follow:

☐ Checkout by 11 am
☐ Dishes in the dishwasher, and start it
☐ Used towels in the tub
☐ Heat down to 16°, windows closed
☐ Lock up, key back in the lockbox

Leave off cleaning jobs if you charge a cleaning fee. Guests notice.

In Keegix, checkout is its own section, and guests can save it as a one-page checkout card. keegix.com""",
  tags='#airbnbtips #hosttips #checkout #shorttermrental #vacationrentaltips #superhost #turnover',
  alt='Carousel with a five-step checkout list template, three things to leave off, and the Keegix checkout section.',
  first='What’s on your checkout list that guests always miss?'),
 dict(n=12, date='Sun Oct 25', time='10:00 am', fmt='Single image', kind='Pricing', folder='p12-pricing', title='Pricing',
  cap="""Start free. Pay per property. 🇨🇦

Free: 1 property
Pro: $9 per property / month
Set up for you: $39 one time

All in Canadian dollars. No card to start.""",
  fb="""Simple pricing, in Canadian dollars:

Free: one property, all sections, the QR sign, up to 5 photos.
Pro: $9 per property per month. No footer, custom colours, unlimited photos. Cancel any time.
Set up for you: $39 one time. Send your notes and I build it.

No card needed to start. keegix.com""",
  tags='#shorttermrental #airbnbhost #vacationrental #smallbusiness #novascotia',
  alt='Keegix pricing in Canadian dollars: Free for one property, Pro at 9 dollars per property per month, and Set up for you at 39 dollars one time.',
  first='Questions about plans? Ask here and I’ll answer.'),
 dict(n=13, date='Wed Oct 28', time='7:00 pm', fmt='Reel', kind='Info', folder='p13-top5-questions-reel', title='The 5 questions every host gets',
  cap="""The 5 questions every host gets. Counting down. 🔢

Answer them once.""",
  fb="""The five questions every host gets, and where they should be answered:

5. Where do we park?
4. Which bin goes out?
3. What time is checkout?
2. Where's the lockbox?
1. What's the wifi password?

Answer them once, on one link. keegix.com""",
  tags='#airbnbhost #hosttips #shorttermrental #vacationrental #guestexperience #strhost',
  alt='Countdown video of five common guest questions, each followed by the Keegix section that answers it, ending with a couple relaxing by a fire.',
  first='Did we miss one? What’s your number one?'),
 dict(n=14, date='Sat Oct 31', time='10:00 am', fmt='Single image', kind='Seasonal humour', folder='p14-halloween', title='The scariest thing in your rental',
  cap="""The scariest thing in your rental: HOUSE_MANUAL_FINAL_v7(2).pdf 👻

Happy Halloween, hosts.""",
  fb="""The scariest thing in your rental: HOUSE_MANUAL_FINAL_v7(2).pdf. 14 pages. 38 MB. 👻

Guests want one screen on their phone, not 14 pages in their inbox. Happy Halloween, hosts.""",
  tags='#halloween #hostlife #airbnbhost #shorttermrental #vacationrental',
  alt='A dark navy post with a cobweb. Text: The scariest thing in your rental. Below, a PDF file named HOUSE_MANUAL_FINAL_v7(2).pdf, 14 pages, 38 MB.',
  first='How many pages is yours? Be honest.'),
 dict(n=15, date='Tue Nov 3', time='7:00 pm', fmt='Carousel (5)', kind='Founder', folder='p15-founder', title='Made in Nova Scotia, by one person',
  cap="""Made in Nova Scotia, by one person. 👋

Hi, I’m Vatsal. I built Keegix after watching hosts answer the same questions one text at a time.

It’s new. Your feedback shapes it.""",
  fb="""Hi, I'm Vatsal. I build small software for service businesses at Waypoint, here in Nova Scotia.

Keegix started with something I kept noticing: hosts spend a lot of evenings answering the same guest questions, one text at a time. So I built the page that answers them.

It deliberately doesn't do bookings, payments, calendar sync or channel management. One job, done properly.

It's new. If you try it and something is off or missing, email me at hello@waypointns.ca. I read every one.""",
  tags='#novascotia #madeinnovascotia #smallbusiness #shopnovascotia #capebreton #shorttermrental #founder',
  alt='Carousel: a Nova Scotia cottage with the words Made in Nova Scotia, by one person, followed by a short founder note, what Keegix does not do, the 39 dollar setup offer and a feedback email.',
  first='If you host in Nova Scotia, I’d love to hear what your guests ask most.'),
 dict(n=16, date='Fri Nov 6', time='7:00 pm', fmt='Reel', kind='Offer', folder='p16-done-for-you-reel', title='Set it up for me, $39',
  cap="""Don’t feel like typing it all? Send me your notes. 📝

I build it. You get the link and the QR sign. One round of changes within 14 days.

$39 CAD, one time.""",
  fb="""Don't feel like typing it all?

Send me your notes, voice memos and a pile of photos. I build your Keegix welcome book for one property, you get the guest link and the QR sign, plus one round of changes within 14 days.

$39 CAD, one time. It lands on the free plan, and you can add Pro any time. Start at keegix.com""",
  tags='#shorttermrental #airbnbhost #vacationrental #welcomebook #hosttips #novascotia',
  alt='Video: messy notes, a voice memo and photos fly together into a finished Keegix guest page on a phone, then a QR sign, and the offer: Set it up for me, 39 dollars one time.',
  first='Off-season is the easy time to get this done before next summer.'),
]
