"""Render Keegix posts.
python3 render.py static posts/p02.html out/p02      -> one PNG per .slide
python3 render.py reel reels/r01.html out/r01.mp4 [fps]
python3 render.py still reels/r01.html out.png t     -> one frame for checking
"""
import asyncio, sys, os, subprocess, shutil, pathlib

ROOT = pathlib.Path(__file__).parent.resolve()

async def static(src, outdir, scale=1):
    from playwright.async_api import async_playwright
    os.makedirs(outdir, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1080, 'height': 1350}, device_scale_factor=scale)
        await pg.goto((ROOT / src).as_uri())
        await pg.evaluate('document.fonts.ready')
        await pg.wait_for_timeout(400)
        els = await pg.query_selector_all('.slide')
        for i, el in enumerate(els, 1):
            name = await el.get_attribute('data-name') or f'slide-{i:02d}'
            await el.screenshot(path=f'{outdir}/{name}.png')
        await b.close()
        print(f'{src}: {len(els)} slides')

async def reel(src, out, fps=30, still_t=None):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1080, 'height': 1920})
        await pg.goto((ROOT / src).as_uri())
        await pg.evaluate('document.fonts.ready')
        await pg.wait_for_timeout(500)
        el = await pg.query_selector('.reel')
        if still_t is not None:
            for k, t in enumerate(still_t):
                await pg.evaluate(f'render({t})')
                o = out if len(still_t) == 1 else out.replace('.png', f'-{k}.png')
                await el.screenshot(path=o, type='png')
            await b.close(); return
        dur = await pg.evaluate('DURATION')
        n = int(round(dur * fps))
        fdir = f'/tmp/frames-{pathlib.Path(out).stem}'
        shutil.rmtree(fdir, ignore_errors=True); os.makedirs(fdir)
        for i in range(n):
            await pg.evaluate(f'render({i / fps})')
            await el.screenshot(path=f'{fdir}/{i:05d}.jpg', type='jpeg', quality=93)
        await b.close()
    os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', str(fps), '-i', f'{fdir}/%05d.jpg',
                    '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-shortest',
                    '-c:v', 'libx264', '-profile:v', 'high', '-pix_fmt', 'yuv420p', '-crf', '17', '-preset', 'medium',
                    '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', out], check=True)
    shutil.rmtree(fdir, ignore_errors=True)
    print(f'{out}: {dur}s, {n} frames')

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'static':
        asyncio.run(static(sys.argv[2], sys.argv[3]))
    elif mode == 'reel':
        asyncio.run(reel(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 30))
    elif mode == 'still':
        asyncio.run(reel(sys.argv[2], sys.argv[3], still_t=[float(x) for x in sys.argv[4].split(',')]))
