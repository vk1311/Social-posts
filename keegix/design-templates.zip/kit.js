// Shared bits for Keegix posts and reels.
const KX = {};
KX.mark = (body = '#15304A', ink = '#fff', dot = '#F4C430') =>
  `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><path d="M20 4h24a8 8 0 0 1 8 8v30L32 60 12 42V12a8 8 0 0 1 8-8z" fill="${body}"/><circle cx="32" cy="17" r="6" fill="${dot}"/><rect x="22" y="31" width="20" height="4" rx="2" fill="${ink}"/><rect x="25" y="39" width="14" height="4" rx="2" fill="${ink}"/></svg>`;
KX.logo = (onDark = false, size = 40) =>
  `<div class="logo" style="font-size:${size}px;color:${onDark ? '#fff' : '#15304A'}">${onDark ? KX.mark('#fff', '#15304A') : KX.mark()}<span>Keegix</span></div>`;

// Guest page, matching keegix.com/p/... markup and styles.
KX.guest = (o = {}) => {
  const name = o.name || 'Harbour Street Cottage';
  const chips = (o.chips || ['Check-in', 'Wifi', 'Parking', 'House rules', 'Trash day', 'Checkout'])
    .map((c) => `<span class="chip ${c === o.active ? 'on' : ''}">${c}</span>`).join('');
  const S = {
    checkin: `<section id="g-checkin"><h2>Check-in</h2><div class="body"><ol><li>Check-in is from 4 pm.</li><li>The lockbox is beside the side door. Code is in your booking message.</li><li>Please put the key back in the lockbox when you leave.</li></ol></div><div class="pics"><img src="../assets/lockbox.jpg"><img src="../assets/door-blue.jpg"></div></section>`,
    wifi: `<section id="g-wifi"><h2>Wifi</h2><div class="card"><div><small>Network</small><b>HarbourStreet-Guest</b></div><span class="sbtn" data-copy1>Copy</span></div><div class="card"><div><small>Password</small><b>saltwater2026</b></div><span class="sbtn" data-copy2>Copy</span></div><div style="margin-top:12px"><span class="sbtn">Show wifi QR code</span></div></section>`,
    parking: `<section id="g-parking"><h2>Parking</h2><div class="body">Two cars fit on the gravel drive. Please don't park on the grass by the stone wall.</div><div style="margin-top:12px"><span class="sbtn">Open in Maps</span></div></section>`,
    appliances: `<section id="g-appliances"><h2>Appliances</h2><div class="body"><b>Thermostat (hall):</b> hold MODE for 3 seconds until it says HEAT, then use the arrows. 20° is cosy.</div><div class="pics"><img src="../assets/thermostat.jpg"></div></section>`,
    rules: `<section id="g-rules"><h2>House rules</h2><div class="body">Quiet hours 10 pm to 8 am. No smoking inside. Dogs welcome, off the beds please.</div></section>`,
    trash: `<section id="g-trash"><h2>Trash day</h2><div class="body">Thursday morning. Green bin and blue bags go to the end of the drive by 7 am.</div></section>`,
    picks: `<section id="g-picks"><h2>Local picks</h2><div class="body">Coffee: the bakery on Main St opens at 7.<br>Groceries: 10 minutes toward town.<br>Walk: the beach trail starts across the road.</div></section>`,
    checkout: `<section id="g-checkout"><h2>Checkout</h2><div class="body"><ol><li>Checkout by 11 am.</li><li>Dishes in the dishwasher and start it.</li><li>Towels in the tub.</li><li>Turn the heat down to 16°.</li><li>Key back in the lockbox.</li></ol></div></section>`,
    offline: `<section id="g-offline" style="border:0"><div class="card" style="display:block;padding:16px 18px"><b style="font-size:17px">Heading somewhere with no signal?</b><div style="font-size:15px;color:#4E5C66;margin-top:4px">Save this guide to your phone now and it still works when the bars run out.</div><div style="margin-top:12px;display:flex;gap:8px"><span class="sbtn fillb">Save as PDF</span><span class="sbtn">Checkout card</span></div></div></section>`,
  };
  const order = o.sections || ['checkin', 'wifi', 'parking', 'appliances', 'rules', 'trash', 'picks', 'checkout', 'offline'];
  return `<div class="gp" style="--gacc:${o.accent || '#15304A'}"><header><p>Welcome to</p><h1>${name}</h1></header><nav>${chips}</nav><main>${order.map((k) => S[k]).join('')}</main><div style="text-align:center;font-size:14px;color:#4E5C66;padding:20px 0 40px">Made with Keegix</div></div>`;
};

KX.phone = (o = {}) =>
  `<div class="phone" id="${o.id || 'phone'}" style="${o.style || ''}"><div class="screen"><div class="notch"></div><div class="scroller" style="position:absolute;inset:0">${o.inner || KX.guest(o)}</div></div></div>`;

KX.sign = (o = {}) =>
  `<div class="sign" style="${o.style || ''}"><div class="top">Welcome</div><h3>${o.name || 'Harbour Street Cottage'}</h3><p>Scan with your phone camera for check-in steps, wifi, house rules and everything else you need.</p><img src="../assets/qr.png"><div class="url">keegix.com</div><div class="mw">Made with Keegix</div></div>`;

KX.foot = (i, n, dark = false, right = '') =>
  `<div class="foot" style="color:${dark ? '#fff' : '#15304A'}">${KX.logo(dark, 30)}${n ? `<div class="dots">${Array.from({ length: n }, (_, k) => `<i class="${k + 1 === i ? 'on' : ''}"></i>`).join('')}</div>` : `<span style="opacity:.85">${right || 'keegix.com'}</span>`}</div>`;
KX.bubble = (text, time, me = false, bg = '#e9e9eb') =>
  `<div style="display:flex;flex-direction:column;align-items:${me ? 'flex-end' : 'flex-start'}"><div style="max-width:720px;background:${me ? '#0a84ff' : bg};color:${me ? '#fff' : '#111'};font-family:-apple-system,Archivo,sans-serif;font-size:36px;line-height:1.25;padding:20px 28px;border-radius:38px">${text}</div>${time ? `<div style="font-size:22px;color:#7a8288;margin:8px 16px 0">${time}</div>` : ''}</div>`;

// animation helpers
KX.clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
KX.p = (t, a, b) => KX.clamp((t - a) / (b - a));
KX.eo = (x) => 1 - Math.pow(1 - x, 3);
KX.eio = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
KX.back = (x) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
KX.lerp = (a, b, x) => a + (b - a) * x;
// visible window with fade in/out
KX.win = (t, a, b, f = 0.35) => KX.clamp(Math.min((t - a) / f, (b - t) / f));
// swap a background <img> to a video frame and wait for it
KX.frame = async (img, dir, t, fps = 24, n = 192, offset = 0) => {
  const i = Math.max(1, Math.min(n, Math.floor((t - offset) * fps) + 1));
  const src = `../assets/${dir}/${String(i).padStart(3, '0')}.jpg`;
  if (!img.src.endsWith(src.slice(2))) { img.src = src; try { await img.decode(); } catch (e) {} }
};
