import sys,glob
from PIL import Image
d=sys.argv[1]; out=sys.argv[2]; w=int(sys.argv[3]) if len(sys.argv)>3 else 360
fs=sorted(glob.glob(d+'/*.png'))
ims=[Image.open(f).convert('RGB') for f in fs]
h=int(w*ims[0].height/ims[0].width)
cols=min(4,len(ims)); rows=(len(ims)+cols-1)//cols
s=Image.new('RGB',(cols*(w+8),rows*(h+8)),'#888')
for i,im in enumerate(ims):
    s.paste(im.resize((w,h)),((i%cols)*(w+8),(i//cols)*(h+8)))
s.save(out)
